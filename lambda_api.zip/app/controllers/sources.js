class Sources {
  constructor() {}
}

module.exports = ( sources => {
  return {};
})( new Sources() );
